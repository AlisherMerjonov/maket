
const Contact = () => (
  <div>
    <div>
      <h1 className=' h1 text-[100px] font-[900]'>Contact Page</h1>
    </div>
  </div>
);

export default Contact;
