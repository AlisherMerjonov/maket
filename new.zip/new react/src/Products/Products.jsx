import axios from "axios"
import { useEffect, useState } from "react"
import { Link } from "react-router-dom"

const Product = () => {
  const [data, setData] = useState([])

  const getData = async () => {
    try {
      const response = await axios.get(
        "https://39ffad45515a8e0e.mokky.dev/root"
      )
      setData(response.data)
    } catch (error) {
      console.error(error)
    }
  }
  useEffect(() => {
    getData()
  }, [])
  return (
    <div>
      <h1 className=" h1 text-[100px] font-[900]">Products Page</h1>

      <div className="cards">
        {data.map((prod) => {
          return (
              <div className="card">
                <img className="img" src={prod.img} alt="" />
                <h1 className="text-[20px] font-[700]">{prod.title}</h1>
                <h1 className="text-[16px] font-[400] text-[green]">
                  {prod.price} $
                </h1>
                <div className="btns">
                <button className="btn">V karzinu</button>
                <button className="btn2">Delete</button>
                </div>
              </div>
          )
        })}
      </div>
    </div>
  )
}

export default Product
