import { Route, Routes } from "react-router-dom"
import Home from "./Home"
import About from "./About"
import Contact from "./Contact"
import Head from "./Head"
import Product from "./Products"

const Root = () => (
  <div className="head max-w-[1200px] mx-[auto] p-[50px]">
    <Head />
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/product" element={<Product />} />
    </Routes>
  </div>
)
export default Root
  