/** @format */

import axios from "axios";
import { useEffect, useState } from "react";

const About = () => {
  const [data, setData] = useState([]);

  const getData = async () => {
    try {
      const response = await axios.get(
        "https://39ffad45515a8e0e.mokky.dev/root"
      );
      setData(response.data);
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    getData();
  }, []);
  return (
    <div>
      <div>
        <h1 className=' h1 text-[100px] font-[900]'>About Page</h1>
      </div>
    </div>
  );
};

export default About;
