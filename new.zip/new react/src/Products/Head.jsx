/** @format */

import { Link, NavLink } from "react-router-dom";
import { SlBasket } from "react-icons/sl";  

const Head = () => (
  <div className='head flex max-w-[1200px] mx-[auto] flex justify-between items-center'>
    <div className='logo'>
      <h1 className=' items-center flex text-[30px] font-[900] gap-[5px] text-blue-500'>
        S/D/B{" "}
        <div className='grid '>
          <small className='text-[15px] font-[400] leading-[15px]'>
            Samsung
          </small>
          <small className='text-[15px] font-[400] leading-[15px]'>
            Dehqonbozor
          </small>{" "}
        </div>
      </h1>
    </div>
    <div className='links flex gap-[25px]'>
      <NavLink className=' link border-4 border-white' to={"/"}>
        Home
      </NavLink>
      <NavLink className=' link border-4 border-white' to={"/about"}>
        About
      </NavLink>
      <NavLink className=' link border-4 border-white' to={"/contact"}>
        Contact
      </NavLink>
      <NavLink className="basket" to={"/basket"}>
      <SlBasket />
      </NavLink>
    </div>
  </div>
);

export default Head;
